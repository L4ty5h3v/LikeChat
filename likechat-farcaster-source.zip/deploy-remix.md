# Развертывание контракта через Remix IDE

## Быстрая инструкция

### Шаг 1: Откройте Remix IDE
Перейдите на https://remix.ethereum.org/

### Шаг 2: Создайте файл контракта
1. В папке `contracts` создайте новый файл `MCTTokenSale.sol`
2. Скопируйте содержимое из `contracts/MCTTokenSale.sol` в ваш проект

### Шаг 3: Скомпилируйте контракт
1. Перейдите на вкладку "Solidity Compiler"
2. Выберите версию компилятора: **0.8.20** или выше
3. Нажмите "Compile MCTTokenSale.sol"
4. Убедитесь, что нет ошибок компиляции

### Шаг 4: Подключите кошелек
1. Перейдите на вкладку "Deploy & Run Transactions"
2. В разделе "Environment" выберите **"Injected Provider - MetaMask"** (или Farcaster Wallet)
3. Убедитесь, что вы подключены к сети **Base** (Chain ID: 8453)
4. Если Base не добавлена, добавьте её:
   - Network Name: Base
   - RPC URL: https://mainnet.base.org
   - Chain ID: 8453
   - Currency Symbol: ETH
   - Block Explorer: https://basescan.org

### Шаг 5: Разверните контракт
1. В разделе "Contract" выберите **"MCTTokenSale"**
2. В поле "Deploy" введите параметры конструктора:
   ```
   _mctToken: 0x04d388da70c32fc5876981097c536c51c8d3d236
   _usdcToken: 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913
   ```
3. Нажмите кнопку **"Deploy"**
4. Подтвердите транзакцию в кошельке

### Шаг 6: Скопируйте адрес контракта
1. После развертывания в разделе "Deployed Contracts" появится ваш контракт
2. Скопируйте адрес контракта (например: `0x1234...5678`)
3. Сохраните этот адрес - он понадобится для настройки приложения

### Шаг 7: Пополните контракт токенами MCT
1. Откройте ваш кошелек (MetaMask/Farcaster Wallet)
2. Найдите токен MCT: `0x04d388da70c32fc5876981097c536c51c8d3d236`
3. Переведите необходимое количество токенов MCT на адрес развернутого контракта
4. Это нужно для того, чтобы контракт мог продавать токены

### Шаг 8: Обновите адрес контракта в приложении
1. Добавьте переменную окружения в Vercel:
   ```
   NEXT_PUBLIC_TOKEN_SALE_CONTRACT_ADDRESS=0x...ваш_адрес_контракта
   ```
2. Или обновите в коде напрямую в файлах:
   - `pages/api/frame/tx/eth.ts`
   - `pages/api/frame/tx/usdc.ts`
   - `lib/farcaster-frame-purchase.ts`
   - `pages/buy-token-frame.tsx`
   - `pages/frame/buy-token.tsx`

## Проверка развертывания

После развертывания проверьте контракт на BaseScan:
1. Откройте https://basescan.org/
2. Вставьте адрес контракта
3. Проверьте:
   - Контракт развернут
   - Баланс токенов MCT > 0
   - Конструктор вызван с правильными параметрами

## Готово! 🎉

Теперь Frame должен работать. Протестируйте:
- https://likechat-farcaster.vercel.app/api/frame/buy-token



